function cosineSimilarity(text1, text2) {
    const tokenize = (text) => text.toLowerCase().match(/\w+/g);
  const words1 = tokenize(text1);
  const words2 = tokenize(text2);

  // Calculate word frequency vectors
  const wordFreq1 = {};
  const wordFreq2 = {};

  for (const word of words1) {
    wordFreq1[word] = (wordFreq1[word] || 0) + 1;
  }

  for (const word of words2) {
    wordFreq2[word] = (wordFreq2[word] || 0) + 1;
  }

  // Calculate dot product and magnitudes
  let dotProduct = 0;
  let magnitude1 = 0;
  let magnitude2 = 0;

  for (const word in wordFreq1) {
    if (wordFreq2[word]) {
      dotProduct += wordFreq1[word] * wordFreq2[word];
    }
    magnitude1 += Math.pow(wordFreq1[word], 2);
  }

  for (const word in wordFreq2) {
    magnitude2 += Math.pow(wordFreq2[word], 2);
  }

  magnitude1 = Math.sqrt(magnitude1);
  magnitude2 = Math.sqrt(magnitude2);
  
    // Calculate cosine similarity as a percentage
    let similarityPercentage = 0;
  
    if (magnitude1 && magnitude2) {
      similarityPercentage = (dotProduct / (magnitude1 * magnitude2)) * 100;
    }
  
    return similarityPercentage;
  }
  
  // Example usage
  const sentence1 = "Shiritani.";
  const sentence2 = "Shiritai.";
  
  const similarity = cosineSimilarity(sentence1, sentence2);
  console.log(`Cosine Similarity: ${similarity.toFixed(2)}%`);
  